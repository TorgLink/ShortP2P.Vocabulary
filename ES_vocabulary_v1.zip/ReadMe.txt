Source: hermitdave/FrequencyWords
Repository: https://github.com/hermitdave/FrequencyWords
License: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
Thanks to: Hermit Dave
